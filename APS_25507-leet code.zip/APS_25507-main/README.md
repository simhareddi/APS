A collection of LeetCode questions to ace the coding interview! - Created using [LeetHub v2](https://github.com/arunbhardwaj/LeetHub-2.0)
<!---LeetCode Topics Start-->
# LeetCode Topics
## Array
|  |
| ------- |
| [0046-permutations](https://github.com/vtu25507bhanu/APS_25507/tree/master/0046-permutations) |
| [0049-group-anagrams](https://github.com/vtu25507bhanu/APS_25507/tree/master/0049-group-anagrams) |
| [0078-subsets](https://github.com/vtu25507bhanu/APS_25507/tree/master/0078-subsets) |
| [0121-best-time-to-buy-and-sell-stock](https://github.com/vtu25507bhanu/APS_25507/tree/master/0121-best-time-to-buy-and-sell-stock) |
| [0169-majority-element](https://github.com/vtu25507bhanu/APS_25507/tree/master/0169-majority-element) |
| [0198-house-robber](https://github.com/vtu25507bhanu/APS_25507/tree/master/0198-house-robber) |
| [0200-number-of-islands](https://github.com/vtu25507bhanu/APS_25507/tree/master/0200-number-of-islands) |
| [0215-kth-largest-element-in-an-array](https://github.com/vtu25507bhanu/APS_25507/tree/master/0215-kth-largest-element-in-an-array) |
| [0219-contains-duplicate-ii](https://github.com/vtu25507bhanu/APS_25507/tree/master/0219-contains-duplicate-ii) |
| [0239-sliding-window-maximum](https://github.com/vtu25507bhanu/APS_25507/tree/master/0239-sliding-window-maximum) |
| [0283-move-zeroes](https://github.com/vtu25507bhanu/APS_25507/tree/master/0283-move-zeroes) |
| [0315-count-of-smaller-numbers-after-self](https://github.com/vtu25507bhanu/APS_25507/tree/master/0315-count-of-smaller-numbers-after-self) |
| [0322-coin-change](https://github.com/vtu25507bhanu/APS_25507/tree/master/0322-coin-change) |
| [0347-top-k-frequent-elements](https://github.com/vtu25507bhanu/APS_25507/tree/master/0347-top-k-frequent-elements) |
| [0373-find-k-pairs-with-smallest-sums](https://github.com/vtu25507bhanu/APS_25507/tree/master/0373-find-k-pairs-with-smallest-sums) |
| [0452-minimum-number-of-arrows-to-burst-balloons](https://github.com/vtu25507bhanu/APS_25507/tree/master/0452-minimum-number-of-arrows-to-burst-balloons) |
| [0474-ones-and-zeroes](https://github.com/vtu25507bhanu/APS_25507/tree/master/0474-ones-and-zeroes) |
| [0496-next-greater-element-i](https://github.com/vtu25507bhanu/APS_25507/tree/master/0496-next-greater-element-i) |
| [0542-01-matrix](https://github.com/vtu25507bhanu/APS_25507/tree/master/0542-01-matrix) |
| [0621-task-scheduler](https://github.com/vtu25507bhanu/APS_25507/tree/master/0621-task-scheduler) |
| [0622-design-circular-queue](https://github.com/vtu25507bhanu/APS_25507/tree/master/0622-design-circular-queue) |
| [0641-design-circular-deque](https://github.com/vtu25507bhanu/APS_25507/tree/master/0641-design-circular-deque) |
| [0695-max-area-of-island](https://github.com/vtu25507bhanu/APS_25507/tree/master/0695-max-area-of-island) |
| [0704-binary-search](https://github.com/vtu25507bhanu/APS_25507/tree/master/0704-binary-search) |
| [0721-accounts-merge](https://github.com/vtu25507bhanu/APS_25507/tree/master/0721-accounts-merge) |
| [0733-flood-fill](https://github.com/vtu25507bhanu/APS_25507/tree/master/0733-flood-fill) |
| [0735-asteroid-collision](https://github.com/vtu25507bhanu/APS_25507/tree/master/0735-asteroid-collision) |
| [0739-daily-temperatures](https://github.com/vtu25507bhanu/APS_25507/tree/master/0739-daily-temperatures) |
| [0746-min-cost-climbing-stairs](https://github.com/vtu25507bhanu/APS_25507/tree/master/0746-min-cost-climbing-stairs) |
| [0929-unique-email-addresses](https://github.com/vtu25507bhanu/APS_25507/tree/master/0929-unique-email-addresses) |
| [0946-validate-stack-sequences](https://github.com/vtu25507bhanu/APS_25507/tree/master/0946-validate-stack-sequences) |
| [0973-k-closest-points-to-origin](https://github.com/vtu25507bhanu/APS_25507/tree/master/0973-k-closest-points-to-origin) |
| [0994-rotting-oranges](https://github.com/vtu25507bhanu/APS_25507/tree/master/0994-rotting-oranges) |
| [1438-longest-continuous-subarray-with-absolute-diff-less-than-or-equal-to-limit](https://github.com/vtu25507bhanu/APS_25507/tree/master/1438-longest-continuous-subarray-with-absolute-diff-less-than-or-equal-to-limit) |
| [1475-final-prices-with-a-special-discount-in-a-shop](https://github.com/vtu25507bhanu/APS_25507/tree/master/1475-final-prices-with-a-special-discount-in-a-shop) |
| [1480-running-sum-of-1d-array](https://github.com/vtu25507bhanu/APS_25507/tree/master/1480-running-sum-of-1d-array) |
## Hash Table
|  |
| ------- |
| [0049-group-anagrams](https://github.com/vtu25507bhanu/APS_25507/tree/master/0049-group-anagrams) |
| [0142-linked-list-cycle-ii](https://github.com/vtu25507bhanu/APS_25507/tree/master/0142-linked-list-cycle-ii) |
| [0160-intersection-of-two-linked-lists](https://github.com/vtu25507bhanu/APS_25507/tree/master/0160-intersection-of-two-linked-lists) |
| [0169-majority-element](https://github.com/vtu25507bhanu/APS_25507/tree/master/0169-majority-element) |
| [0202-happy-number](https://github.com/vtu25507bhanu/APS_25507/tree/master/0202-happy-number) |
| [0219-contains-duplicate-ii](https://github.com/vtu25507bhanu/APS_25507/tree/master/0219-contains-duplicate-ii) |
| [0347-top-k-frequent-elements](https://github.com/vtu25507bhanu/APS_25507/tree/master/0347-top-k-frequent-elements) |
| [0387-first-unique-character-in-a-string](https://github.com/vtu25507bhanu/APS_25507/tree/master/0387-first-unique-character-in-a-string) |
| [0496-next-greater-element-i](https://github.com/vtu25507bhanu/APS_25507/tree/master/0496-next-greater-element-i) |
| [0621-task-scheduler](https://github.com/vtu25507bhanu/APS_25507/tree/master/0621-task-scheduler) |
| [0721-accounts-merge](https://github.com/vtu25507bhanu/APS_25507/tree/master/0721-accounts-merge) |
| [0929-unique-email-addresses](https://github.com/vtu25507bhanu/APS_25507/tree/master/0929-unique-email-addresses) |
| [0987-vertical-order-traversal-of-a-binary-tree](https://github.com/vtu25507bhanu/APS_25507/tree/master/0987-vertical-order-traversal-of-a-binary-tree) |
| [1763-longest-nice-substring](https://github.com/vtu25507bhanu/APS_25507/tree/master/1763-longest-nice-substring) |
## Sliding Window
|  |
| ------- |
| [0219-contains-duplicate-ii](https://github.com/vtu25507bhanu/APS_25507/tree/master/0219-contains-duplicate-ii) |
| [0239-sliding-window-maximum](https://github.com/vtu25507bhanu/APS_25507/tree/master/0239-sliding-window-maximum) |
| [1438-longest-continuous-subarray-with-absolute-diff-less-than-or-equal-to-limit](https://github.com/vtu25507bhanu/APS_25507/tree/master/1438-longest-continuous-subarray-with-absolute-diff-less-than-or-equal-to-limit) |
| [1763-longest-nice-substring](https://github.com/vtu25507bhanu/APS_25507/tree/master/1763-longest-nice-substring) |
## Prefix Sum
|  |
| ------- |
| [1480-running-sum-of-1d-array](https://github.com/vtu25507bhanu/APS_25507/tree/master/1480-running-sum-of-1d-array) |
## Binary Search
|  |
| ------- |
| [0315-count-of-smaller-numbers-after-self](https://github.com/vtu25507bhanu/APS_25507/tree/master/0315-count-of-smaller-numbers-after-self) |
| [0704-binary-search](https://github.com/vtu25507bhanu/APS_25507/tree/master/0704-binary-search) |
## Dynamic Programming
|  |
| ------- |
| [0062-unique-paths](https://github.com/vtu25507bhanu/APS_25507/tree/master/0062-unique-paths) |
| [0070-climbing-stairs](https://github.com/vtu25507bhanu/APS_25507/tree/master/0070-climbing-stairs) |
| [0121-best-time-to-buy-and-sell-stock](https://github.com/vtu25507bhanu/APS_25507/tree/master/0121-best-time-to-buy-and-sell-stock) |
| [0198-house-robber](https://github.com/vtu25507bhanu/APS_25507/tree/master/0198-house-robber) |
| [0322-coin-change](https://github.com/vtu25507bhanu/APS_25507/tree/master/0322-coin-change) |
| [0474-ones-and-zeroes](https://github.com/vtu25507bhanu/APS_25507/tree/master/0474-ones-and-zeroes) |
| [0542-01-matrix](https://github.com/vtu25507bhanu/APS_25507/tree/master/0542-01-matrix) |
| [0746-min-cost-climbing-stairs](https://github.com/vtu25507bhanu/APS_25507/tree/master/0746-min-cost-climbing-stairs) |
## String
|  |
| ------- |
| [0020-valid-parentheses](https://github.com/vtu25507bhanu/APS_25507/tree/master/0020-valid-parentheses) |
| [0049-group-anagrams](https://github.com/vtu25507bhanu/APS_25507/tree/master/0049-group-anagrams) |
| [0257-binary-tree-paths](https://github.com/vtu25507bhanu/APS_25507/tree/master/0257-binary-tree-paths) |
| [0344-reverse-string](https://github.com/vtu25507bhanu/APS_25507/tree/master/0344-reverse-string) |
| [0387-first-unique-character-in-a-string](https://github.com/vtu25507bhanu/APS_25507/tree/master/0387-first-unique-character-in-a-string) |
| [0474-ones-and-zeroes](https://github.com/vtu25507bhanu/APS_25507/tree/master/0474-ones-and-zeroes) |
| [0721-accounts-merge](https://github.com/vtu25507bhanu/APS_25507/tree/master/0721-accounts-merge) |
| [0929-unique-email-addresses](https://github.com/vtu25507bhanu/APS_25507/tree/master/0929-unique-email-addresses) |
| [1249-minimum-remove-to-make-valid-parentheses](https://github.com/vtu25507bhanu/APS_25507/tree/master/1249-minimum-remove-to-make-valid-parentheses) |
| [1763-longest-nice-substring](https://github.com/vtu25507bhanu/APS_25507/tree/master/1763-longest-nice-substring) |
## Queue
|  |
| ------- |
| [0232-implement-queue-using-stacks](https://github.com/vtu25507bhanu/APS_25507/tree/master/0232-implement-queue-using-stacks) |
| [0239-sliding-window-maximum](https://github.com/vtu25507bhanu/APS_25507/tree/master/0239-sliding-window-maximum) |
| [0387-first-unique-character-in-a-string](https://github.com/vtu25507bhanu/APS_25507/tree/master/0387-first-unique-character-in-a-string) |
| [0622-design-circular-queue](https://github.com/vtu25507bhanu/APS_25507/tree/master/0622-design-circular-queue) |
| [0641-design-circular-deque](https://github.com/vtu25507bhanu/APS_25507/tree/master/0641-design-circular-deque) |
| [0933-number-of-recent-calls](https://github.com/vtu25507bhanu/APS_25507/tree/master/0933-number-of-recent-calls) |
| [1438-longest-continuous-subarray-with-absolute-diff-less-than-or-equal-to-limit](https://github.com/vtu25507bhanu/APS_25507/tree/master/1438-longest-continuous-subarray-with-absolute-diff-less-than-or-equal-to-limit) |
## Counting
|  |
| ------- |
| [0169-majority-element](https://github.com/vtu25507bhanu/APS_25507/tree/master/0169-majority-element) |
| [0347-top-k-frequent-elements](https://github.com/vtu25507bhanu/APS_25507/tree/master/0347-top-k-frequent-elements) |
| [0387-first-unique-character-in-a-string](https://github.com/vtu25507bhanu/APS_25507/tree/master/0387-first-unique-character-in-a-string) |
| [0621-task-scheduler](https://github.com/vtu25507bhanu/APS_25507/tree/master/0621-task-scheduler) |
## Two Pointers
|  |
| ------- |
| [0142-linked-list-cycle-ii](https://github.com/vtu25507bhanu/APS_25507/tree/master/0142-linked-list-cycle-ii) |
| [0160-intersection-of-two-linked-lists](https://github.com/vtu25507bhanu/APS_25507/tree/master/0160-intersection-of-two-linked-lists) |
| [0202-happy-number](https://github.com/vtu25507bhanu/APS_25507/tree/master/0202-happy-number) |
| [0234-palindrome-linked-list](https://github.com/vtu25507bhanu/APS_25507/tree/master/0234-palindrome-linked-list) |
| [0283-move-zeroes](https://github.com/vtu25507bhanu/APS_25507/tree/master/0283-move-zeroes) |
| [0344-reverse-string](https://github.com/vtu25507bhanu/APS_25507/tree/master/0344-reverse-string) |
| [0876-middle-of-the-linked-list](https://github.com/vtu25507bhanu/APS_25507/tree/master/0876-middle-of-the-linked-list) |
## Linked List
|  |
| ------- |
| [0021-merge-two-sorted-lists](https://github.com/vtu25507bhanu/APS_25507/tree/master/0021-merge-two-sorted-lists) |
| [0023-merge-k-sorted-lists](https://github.com/vtu25507bhanu/APS_25507/tree/master/0023-merge-k-sorted-lists) |
| [0025-reverse-nodes-in-k-group](https://github.com/vtu25507bhanu/APS_25507/tree/master/0025-reverse-nodes-in-k-group) |
| [0142-linked-list-cycle-ii](https://github.com/vtu25507bhanu/APS_25507/tree/master/0142-linked-list-cycle-ii) |
| [0160-intersection-of-two-linked-lists](https://github.com/vtu25507bhanu/APS_25507/tree/master/0160-intersection-of-two-linked-lists) |
| [0206-reverse-linked-list](https://github.com/vtu25507bhanu/APS_25507/tree/master/0206-reverse-linked-list) |
| [0234-palindrome-linked-list](https://github.com/vtu25507bhanu/APS_25507/tree/master/0234-palindrome-linked-list) |
| [0622-design-circular-queue](https://github.com/vtu25507bhanu/APS_25507/tree/master/0622-design-circular-queue) |
| [0641-design-circular-deque](https://github.com/vtu25507bhanu/APS_25507/tree/master/0641-design-circular-deque) |
| [0876-middle-of-the-linked-list](https://github.com/vtu25507bhanu/APS_25507/tree/master/0876-middle-of-the-linked-list) |
## Stack
|  |
| ------- |
| [0020-valid-parentheses](https://github.com/vtu25507bhanu/APS_25507/tree/master/0020-valid-parentheses) |
| [0094-binary-tree-inorder-traversal](https://github.com/vtu25507bhanu/APS_25507/tree/master/0094-binary-tree-inorder-traversal) |
| [0144-binary-tree-preorder-traversal](https://github.com/vtu25507bhanu/APS_25507/tree/master/0144-binary-tree-preorder-traversal) |
| [0232-implement-queue-using-stacks](https://github.com/vtu25507bhanu/APS_25507/tree/master/0232-implement-queue-using-stacks) |
| [0234-palindrome-linked-list](https://github.com/vtu25507bhanu/APS_25507/tree/master/0234-palindrome-linked-list) |
| [0496-next-greater-element-i](https://github.com/vtu25507bhanu/APS_25507/tree/master/0496-next-greater-element-i) |
| [0735-asteroid-collision](https://github.com/vtu25507bhanu/APS_25507/tree/master/0735-asteroid-collision) |
| [0739-daily-temperatures](https://github.com/vtu25507bhanu/APS_25507/tree/master/0739-daily-temperatures) |
| [0901-online-stock-span](https://github.com/vtu25507bhanu/APS_25507/tree/master/0901-online-stock-span) |
| [0946-validate-stack-sequences](https://github.com/vtu25507bhanu/APS_25507/tree/master/0946-validate-stack-sequences) |
| [1249-minimum-remove-to-make-valid-parentheses](https://github.com/vtu25507bhanu/APS_25507/tree/master/1249-minimum-remove-to-make-valid-parentheses) |
| [1475-final-prices-with-a-special-discount-in-a-shop](https://github.com/vtu25507bhanu/APS_25507/tree/master/1475-final-prices-with-a-special-discount-in-a-shop) |
## Recursion
|  |
| ------- |
| [0021-merge-two-sorted-lists](https://github.com/vtu25507bhanu/APS_25507/tree/master/0021-merge-two-sorted-lists) |
| [0025-reverse-nodes-in-k-group](https://github.com/vtu25507bhanu/APS_25507/tree/master/0025-reverse-nodes-in-k-group) |
| [0206-reverse-linked-list](https://github.com/vtu25507bhanu/APS_25507/tree/master/0206-reverse-linked-list) |
| [0234-palindrome-linked-list](https://github.com/vtu25507bhanu/APS_25507/tree/master/0234-palindrome-linked-list) |
## Divide and Conquer
|  |
| ------- |
| [0023-merge-k-sorted-lists](https://github.com/vtu25507bhanu/APS_25507/tree/master/0023-merge-k-sorted-lists) |
| [0169-majority-element](https://github.com/vtu25507bhanu/APS_25507/tree/master/0169-majority-element) |
| [0190-reverse-bits](https://github.com/vtu25507bhanu/APS_25507/tree/master/0190-reverse-bits) |
| [0215-kth-largest-element-in-an-array](https://github.com/vtu25507bhanu/APS_25507/tree/master/0215-kth-largest-element-in-an-array) |
| [0315-count-of-smaller-numbers-after-self](https://github.com/vtu25507bhanu/APS_25507/tree/master/0315-count-of-smaller-numbers-after-self) |
| [0347-top-k-frequent-elements](https://github.com/vtu25507bhanu/APS_25507/tree/master/0347-top-k-frequent-elements) |
| [0973-k-closest-points-to-origin](https://github.com/vtu25507bhanu/APS_25507/tree/master/0973-k-closest-points-to-origin) |
| [1763-longest-nice-substring](https://github.com/vtu25507bhanu/APS_25507/tree/master/1763-longest-nice-substring) |
## Heap (Priority Queue)
|  |
| ------- |
| [0023-merge-k-sorted-lists](https://github.com/vtu25507bhanu/APS_25507/tree/master/0023-merge-k-sorted-lists) |
| [0215-kth-largest-element-in-an-array](https://github.com/vtu25507bhanu/APS_25507/tree/master/0215-kth-largest-element-in-an-array) |
| [0239-sliding-window-maximum](https://github.com/vtu25507bhanu/APS_25507/tree/master/0239-sliding-window-maximum) |
| [0347-top-k-frequent-elements](https://github.com/vtu25507bhanu/APS_25507/tree/master/0347-top-k-frequent-elements) |
| [0373-find-k-pairs-with-smallest-sums](https://github.com/vtu25507bhanu/APS_25507/tree/master/0373-find-k-pairs-with-smallest-sums) |
| [0621-task-scheduler](https://github.com/vtu25507bhanu/APS_25507/tree/master/0621-task-scheduler) |
| [0973-k-closest-points-to-origin](https://github.com/vtu25507bhanu/APS_25507/tree/master/0973-k-closest-points-to-origin) |
| [1438-longest-continuous-subarray-with-absolute-diff-less-than-or-equal-to-limit](https://github.com/vtu25507bhanu/APS_25507/tree/master/1438-longest-continuous-subarray-with-absolute-diff-less-than-or-equal-to-limit) |
## Merge Sort
|  |
| ------- |
| [0023-merge-k-sorted-lists](https://github.com/vtu25507bhanu/APS_25507/tree/master/0023-merge-k-sorted-lists) |
| [0315-count-of-smaller-numbers-after-self](https://github.com/vtu25507bhanu/APS_25507/tree/master/0315-count-of-smaller-numbers-after-self) |
## Monotonic Stack
|  |
| ------- |
| [0496-next-greater-element-i](https://github.com/vtu25507bhanu/APS_25507/tree/master/0496-next-greater-element-i) |
| [0739-daily-temperatures](https://github.com/vtu25507bhanu/APS_25507/tree/master/0739-daily-temperatures) |
| [0901-online-stock-span](https://github.com/vtu25507bhanu/APS_25507/tree/master/0901-online-stock-span) |
| [1475-final-prices-with-a-special-discount-in-a-shop](https://github.com/vtu25507bhanu/APS_25507/tree/master/1475-final-prices-with-a-special-discount-in-a-shop) |
## Design
|  |
| ------- |
| [0232-implement-queue-using-stacks](https://github.com/vtu25507bhanu/APS_25507/tree/master/0232-implement-queue-using-stacks) |
| [0622-design-circular-queue](https://github.com/vtu25507bhanu/APS_25507/tree/master/0622-design-circular-queue) |
| [0641-design-circular-deque](https://github.com/vtu25507bhanu/APS_25507/tree/master/0641-design-circular-deque) |
| [0901-online-stock-span](https://github.com/vtu25507bhanu/APS_25507/tree/master/0901-online-stock-span) |
| [0933-number-of-recent-calls](https://github.com/vtu25507bhanu/APS_25507/tree/master/0933-number-of-recent-calls) |
## Data Stream
|  |
| ------- |
| [0901-online-stock-span](https://github.com/vtu25507bhanu/APS_25507/tree/master/0901-online-stock-span) |
| [0933-number-of-recent-calls](https://github.com/vtu25507bhanu/APS_25507/tree/master/0933-number-of-recent-calls) |
## Depth-First Search
|  |
| ------- |
| [0094-binary-tree-inorder-traversal](https://github.com/vtu25507bhanu/APS_25507/tree/master/0094-binary-tree-inorder-traversal) |
| [0100-same-tree](https://github.com/vtu25507bhanu/APS_25507/tree/master/0100-same-tree) |
| [0101-symmetric-tree](https://github.com/vtu25507bhanu/APS_25507/tree/master/0101-symmetric-tree) |
| [0112-path-sum](https://github.com/vtu25507bhanu/APS_25507/tree/master/0112-path-sum) |
| [0113-path-sum-ii](https://github.com/vtu25507bhanu/APS_25507/tree/master/0113-path-sum-ii) |
| [0144-binary-tree-preorder-traversal](https://github.com/vtu25507bhanu/APS_25507/tree/master/0144-binary-tree-preorder-traversal) |
| [0199-binary-tree-right-side-view](https://github.com/vtu25507bhanu/APS_25507/tree/master/0199-binary-tree-right-side-view) |
| [0200-number-of-islands](https://github.com/vtu25507bhanu/APS_25507/tree/master/0200-number-of-islands) |
| [0207-course-schedule](https://github.com/vtu25507bhanu/APS_25507/tree/master/0207-course-schedule) |
| [0210-course-schedule-ii](https://github.com/vtu25507bhanu/APS_25507/tree/master/0210-course-schedule-ii) |
| [0235-lowest-common-ancestor-of-a-binary-search-tree](https://github.com/vtu25507bhanu/APS_25507/tree/master/0235-lowest-common-ancestor-of-a-binary-search-tree) |
| [0236-lowest-common-ancestor-of-a-binary-tree](https://github.com/vtu25507bhanu/APS_25507/tree/master/0236-lowest-common-ancestor-of-a-binary-tree) |
| [0257-binary-tree-paths](https://github.com/vtu25507bhanu/APS_25507/tree/master/0257-binary-tree-paths) |
| [0547-number-of-provinces](https://github.com/vtu25507bhanu/APS_25507/tree/master/0547-number-of-provinces) |
| [0695-max-area-of-island](https://github.com/vtu25507bhanu/APS_25507/tree/master/0695-max-area-of-island) |
| [0721-accounts-merge](https://github.com/vtu25507bhanu/APS_25507/tree/master/0721-accounts-merge) |
| [0733-flood-fill](https://github.com/vtu25507bhanu/APS_25507/tree/master/0733-flood-fill) |
| [0841-keys-and-rooms](https://github.com/vtu25507bhanu/APS_25507/tree/master/0841-keys-and-rooms) |
| [0987-vertical-order-traversal-of-a-binary-tree](https://github.com/vtu25507bhanu/APS_25507/tree/master/0987-vertical-order-traversal-of-a-binary-tree) |
| [1203-sort-items-by-groups-respecting-dependencies](https://github.com/vtu25507bhanu/APS_25507/tree/master/1203-sort-items-by-groups-respecting-dependencies) |
| [1971-find-if-path-exists-in-graph](https://github.com/vtu25507bhanu/APS_25507/tree/master/1971-find-if-path-exists-in-graph) |
## Breadth-First Search
|  |
| ------- |
| [0100-same-tree](https://github.com/vtu25507bhanu/APS_25507/tree/master/0100-same-tree) |
| [0101-symmetric-tree](https://github.com/vtu25507bhanu/APS_25507/tree/master/0101-symmetric-tree) |
| [0102-binary-tree-level-order-traversal](https://github.com/vtu25507bhanu/APS_25507/tree/master/0102-binary-tree-level-order-traversal) |
| [0112-path-sum](https://github.com/vtu25507bhanu/APS_25507/tree/master/0112-path-sum) |
| [0199-binary-tree-right-side-view](https://github.com/vtu25507bhanu/APS_25507/tree/master/0199-binary-tree-right-side-view) |
| [0200-number-of-islands](https://github.com/vtu25507bhanu/APS_25507/tree/master/0200-number-of-islands) |
| [0207-course-schedule](https://github.com/vtu25507bhanu/APS_25507/tree/master/0207-course-schedule) |
| [0210-course-schedule-ii](https://github.com/vtu25507bhanu/APS_25507/tree/master/0210-course-schedule-ii) |
| [0322-coin-change](https://github.com/vtu25507bhanu/APS_25507/tree/master/0322-coin-change) |
| [0542-01-matrix](https://github.com/vtu25507bhanu/APS_25507/tree/master/0542-01-matrix) |
| [0547-number-of-provinces](https://github.com/vtu25507bhanu/APS_25507/tree/master/0547-number-of-provinces) |
| [0695-max-area-of-island](https://github.com/vtu25507bhanu/APS_25507/tree/master/0695-max-area-of-island) |
| [0721-accounts-merge](https://github.com/vtu25507bhanu/APS_25507/tree/master/0721-accounts-merge) |
| [0733-flood-fill](https://github.com/vtu25507bhanu/APS_25507/tree/master/0733-flood-fill) |
| [0841-keys-and-rooms](https://github.com/vtu25507bhanu/APS_25507/tree/master/0841-keys-and-rooms) |
| [0987-vertical-order-traversal-of-a-binary-tree](https://github.com/vtu25507bhanu/APS_25507/tree/master/0987-vertical-order-traversal-of-a-binary-tree) |
| [0994-rotting-oranges](https://github.com/vtu25507bhanu/APS_25507/tree/master/0994-rotting-oranges) |
| [1129-shortest-path-with-alternating-colors](https://github.com/vtu25507bhanu/APS_25507/tree/master/1129-shortest-path-with-alternating-colors) |
| [1203-sort-items-by-groups-respecting-dependencies](https://github.com/vtu25507bhanu/APS_25507/tree/master/1203-sort-items-by-groups-respecting-dependencies) |
| [1971-find-if-path-exists-in-graph](https://github.com/vtu25507bhanu/APS_25507/tree/master/1971-find-if-path-exists-in-graph) |
## Union-Find
|  |
| ------- |
| [0200-number-of-islands](https://github.com/vtu25507bhanu/APS_25507/tree/master/0200-number-of-islands) |
| [0547-number-of-provinces](https://github.com/vtu25507bhanu/APS_25507/tree/master/0547-number-of-provinces) |
| [0695-max-area-of-island](https://github.com/vtu25507bhanu/APS_25507/tree/master/0695-max-area-of-island) |
| [0721-accounts-merge](https://github.com/vtu25507bhanu/APS_25507/tree/master/0721-accounts-merge) |
| [1971-find-if-path-exists-in-graph](https://github.com/vtu25507bhanu/APS_25507/tree/master/1971-find-if-path-exists-in-graph) |
## Graph Theory
|  |
| ------- |
| [0207-course-schedule](https://github.com/vtu25507bhanu/APS_25507/tree/master/0207-course-schedule) |
| [0210-course-schedule-ii](https://github.com/vtu25507bhanu/APS_25507/tree/master/0210-course-schedule-ii) |
| [0547-number-of-provinces](https://github.com/vtu25507bhanu/APS_25507/tree/master/0547-number-of-provinces) |
| [0841-keys-and-rooms](https://github.com/vtu25507bhanu/APS_25507/tree/master/0841-keys-and-rooms) |
| [1129-shortest-path-with-alternating-colors](https://github.com/vtu25507bhanu/APS_25507/tree/master/1129-shortest-path-with-alternating-colors) |
| [1203-sort-items-by-groups-respecting-dependencies](https://github.com/vtu25507bhanu/APS_25507/tree/master/1203-sort-items-by-groups-respecting-dependencies) |
| [1971-find-if-path-exists-in-graph](https://github.com/vtu25507bhanu/APS_25507/tree/master/1971-find-if-path-exists-in-graph) |
## Matrix
|  |
| ------- |
| [0200-number-of-islands](https://github.com/vtu25507bhanu/APS_25507/tree/master/0200-number-of-islands) |
| [0542-01-matrix](https://github.com/vtu25507bhanu/APS_25507/tree/master/0542-01-matrix) |
| [0695-max-area-of-island](https://github.com/vtu25507bhanu/APS_25507/tree/master/0695-max-area-of-island) |
| [0733-flood-fill](https://github.com/vtu25507bhanu/APS_25507/tree/master/0733-flood-fill) |
| [0994-rotting-oranges](https://github.com/vtu25507bhanu/APS_25507/tree/master/0994-rotting-oranges) |
## Topological Sort
|  |
| ------- |
| [0207-course-schedule](https://github.com/vtu25507bhanu/APS_25507/tree/master/0207-course-schedule) |
| [0210-course-schedule-ii](https://github.com/vtu25507bhanu/APS_25507/tree/master/0210-course-schedule-ii) |
| [1203-sort-items-by-groups-respecting-dependencies](https://github.com/vtu25507bhanu/APS_25507/tree/master/1203-sort-items-by-groups-respecting-dependencies) |
## Sorting
|  |
| ------- |
| [0049-group-anagrams](https://github.com/vtu25507bhanu/APS_25507/tree/master/0049-group-anagrams) |
| [0169-majority-element](https://github.com/vtu25507bhanu/APS_25507/tree/master/0169-majority-element) |
| [0215-kth-largest-element-in-an-array](https://github.com/vtu25507bhanu/APS_25507/tree/master/0215-kth-largest-element-in-an-array) |
| [0347-top-k-frequent-elements](https://github.com/vtu25507bhanu/APS_25507/tree/master/0347-top-k-frequent-elements) |
| [0452-minimum-number-of-arrows-to-burst-balloons](https://github.com/vtu25507bhanu/APS_25507/tree/master/0452-minimum-number-of-arrows-to-burst-balloons) |
| [0621-task-scheduler](https://github.com/vtu25507bhanu/APS_25507/tree/master/0621-task-scheduler) |
| [0721-accounts-merge](https://github.com/vtu25507bhanu/APS_25507/tree/master/0721-accounts-merge) |
| [0973-k-closest-points-to-origin](https://github.com/vtu25507bhanu/APS_25507/tree/master/0973-k-closest-points-to-origin) |
| [0987-vertical-order-traversal-of-a-binary-tree](https://github.com/vtu25507bhanu/APS_25507/tree/master/0987-vertical-order-traversal-of-a-binary-tree) |
## Math
|  |
| ------- |
| [0062-unique-paths](https://github.com/vtu25507bhanu/APS_25507/tree/master/0062-unique-paths) |
| [0070-climbing-stairs](https://github.com/vtu25507bhanu/APS_25507/tree/master/0070-climbing-stairs) |
| [0202-happy-number](https://github.com/vtu25507bhanu/APS_25507/tree/master/0202-happy-number) |
| [0973-k-closest-points-to-origin](https://github.com/vtu25507bhanu/APS_25507/tree/master/0973-k-closest-points-to-origin) |
## Bit Manipulation
|  |
| ------- |
| [0078-subsets](https://github.com/vtu25507bhanu/APS_25507/tree/master/0078-subsets) |
| [0190-reverse-bits](https://github.com/vtu25507bhanu/APS_25507/tree/master/0190-reverse-bits) |
| [1763-longest-nice-substring](https://github.com/vtu25507bhanu/APS_25507/tree/master/1763-longest-nice-substring) |
## Binary Indexed Tree
|  |
| ------- |
| [0315-count-of-smaller-numbers-after-self](https://github.com/vtu25507bhanu/APS_25507/tree/master/0315-count-of-smaller-numbers-after-self) |
## Segment Tree
|  |
| ------- |
| [0315-count-of-smaller-numbers-after-self](https://github.com/vtu25507bhanu/APS_25507/tree/master/0315-count-of-smaller-numbers-after-self) |
## Ordered Set
|  |
| ------- |
| [0315-count-of-smaller-numbers-after-self](https://github.com/vtu25507bhanu/APS_25507/tree/master/0315-count-of-smaller-numbers-after-self) |
| [1438-longest-continuous-subarray-with-absolute-diff-less-than-or-equal-to-limit](https://github.com/vtu25507bhanu/APS_25507/tree/master/1438-longest-continuous-subarray-with-absolute-diff-less-than-or-equal-to-limit) |
## Geometry
|  |
| ------- |
| [0973-k-closest-points-to-origin](https://github.com/vtu25507bhanu/APS_25507/tree/master/0973-k-closest-points-to-origin) |
## Quickselect
|  |
| ------- |
| [0215-kth-largest-element-in-an-array](https://github.com/vtu25507bhanu/APS_25507/tree/master/0215-kth-largest-element-in-an-array) |
| [0347-top-k-frequent-elements](https://github.com/vtu25507bhanu/APS_25507/tree/master/0347-top-k-frequent-elements) |
| [0973-k-closest-points-to-origin](https://github.com/vtu25507bhanu/APS_25507/tree/master/0973-k-closest-points-to-origin) |
## Memoization
|  |
| ------- |
| [0070-climbing-stairs](https://github.com/vtu25507bhanu/APS_25507/tree/master/0070-climbing-stairs) |
## Combinatorics
|  |
| ------- |
| [0062-unique-paths](https://github.com/vtu25507bhanu/APS_25507/tree/master/0062-unique-paths) |
## Greedy
|  |
| ------- |
| [0452-minimum-number-of-arrows-to-burst-balloons](https://github.com/vtu25507bhanu/APS_25507/tree/master/0452-minimum-number-of-arrows-to-burst-balloons) |
| [0621-task-scheduler](https://github.com/vtu25507bhanu/APS_25507/tree/master/0621-task-scheduler) |
## Backtracking
|  |
| ------- |
| [0046-permutations](https://github.com/vtu25507bhanu/APS_25507/tree/master/0046-permutations) |
| [0077-combinations](https://github.com/vtu25507bhanu/APS_25507/tree/master/0077-combinations) |
| [0078-subsets](https://github.com/vtu25507bhanu/APS_25507/tree/master/0078-subsets) |
| [0113-path-sum-ii](https://github.com/vtu25507bhanu/APS_25507/tree/master/0113-path-sum-ii) |
| [0257-binary-tree-paths](https://github.com/vtu25507bhanu/APS_25507/tree/master/0257-binary-tree-paths) |
## Simulation
|  |
| ------- |
| [0735-asteroid-collision](https://github.com/vtu25507bhanu/APS_25507/tree/master/0735-asteroid-collision) |
| [0946-validate-stack-sequences](https://github.com/vtu25507bhanu/APS_25507/tree/master/0946-validate-stack-sequences) |
## Monotonic Queue
|  |
| ------- |
| [0239-sliding-window-maximum](https://github.com/vtu25507bhanu/APS_25507/tree/master/0239-sliding-window-maximum) |
| [1438-longest-continuous-subarray-with-absolute-diff-less-than-or-equal-to-limit](https://github.com/vtu25507bhanu/APS_25507/tree/master/1438-longest-continuous-subarray-with-absolute-diff-less-than-or-equal-to-limit) |
## Tree
|  |
| ------- |
| [0094-binary-tree-inorder-traversal](https://github.com/vtu25507bhanu/APS_25507/tree/master/0094-binary-tree-inorder-traversal) |
| [0100-same-tree](https://github.com/vtu25507bhanu/APS_25507/tree/master/0100-same-tree) |
| [0101-symmetric-tree](https://github.com/vtu25507bhanu/APS_25507/tree/master/0101-symmetric-tree) |
| [0102-binary-tree-level-order-traversal](https://github.com/vtu25507bhanu/APS_25507/tree/master/0102-binary-tree-level-order-traversal) |
| [0112-path-sum](https://github.com/vtu25507bhanu/APS_25507/tree/master/0112-path-sum) |
| [0113-path-sum-ii](https://github.com/vtu25507bhanu/APS_25507/tree/master/0113-path-sum-ii) |
| [0144-binary-tree-preorder-traversal](https://github.com/vtu25507bhanu/APS_25507/tree/master/0144-binary-tree-preorder-traversal) |
| [0199-binary-tree-right-side-view](https://github.com/vtu25507bhanu/APS_25507/tree/master/0199-binary-tree-right-side-view) |
| [0235-lowest-common-ancestor-of-a-binary-search-tree](https://github.com/vtu25507bhanu/APS_25507/tree/master/0235-lowest-common-ancestor-of-a-binary-search-tree) |
| [0236-lowest-common-ancestor-of-a-binary-tree](https://github.com/vtu25507bhanu/APS_25507/tree/master/0236-lowest-common-ancestor-of-a-binary-tree) |
| [0257-binary-tree-paths](https://github.com/vtu25507bhanu/APS_25507/tree/master/0257-binary-tree-paths) |
| [0987-vertical-order-traversal-of-a-binary-tree](https://github.com/vtu25507bhanu/APS_25507/tree/master/0987-vertical-order-traversal-of-a-binary-tree) |
## Binary Tree
|  |
| ------- |
| [0094-binary-tree-inorder-traversal](https://github.com/vtu25507bhanu/APS_25507/tree/master/0094-binary-tree-inorder-traversal) |
| [0100-same-tree](https://github.com/vtu25507bhanu/APS_25507/tree/master/0100-same-tree) |
| [0101-symmetric-tree](https://github.com/vtu25507bhanu/APS_25507/tree/master/0101-symmetric-tree) |
| [0102-binary-tree-level-order-traversal](https://github.com/vtu25507bhanu/APS_25507/tree/master/0102-binary-tree-level-order-traversal) |
| [0112-path-sum](https://github.com/vtu25507bhanu/APS_25507/tree/master/0112-path-sum) |
| [0113-path-sum-ii](https://github.com/vtu25507bhanu/APS_25507/tree/master/0113-path-sum-ii) |
| [0144-binary-tree-preorder-traversal](https://github.com/vtu25507bhanu/APS_25507/tree/master/0144-binary-tree-preorder-traversal) |
| [0199-binary-tree-right-side-view](https://github.com/vtu25507bhanu/APS_25507/tree/master/0199-binary-tree-right-side-view) |
| [0235-lowest-common-ancestor-of-a-binary-search-tree](https://github.com/vtu25507bhanu/APS_25507/tree/master/0235-lowest-common-ancestor-of-a-binary-search-tree) |
| [0236-lowest-common-ancestor-of-a-binary-tree](https://github.com/vtu25507bhanu/APS_25507/tree/master/0236-lowest-common-ancestor-of-a-binary-tree) |
| [0257-binary-tree-paths](https://github.com/vtu25507bhanu/APS_25507/tree/master/0257-binary-tree-paths) |
| [0987-vertical-order-traversal-of-a-binary-tree](https://github.com/vtu25507bhanu/APS_25507/tree/master/0987-vertical-order-traversal-of-a-binary-tree) |
## Binary Search Tree
|  |
| ------- |
| [0235-lowest-common-ancestor-of-a-binary-search-tree](https://github.com/vtu25507bhanu/APS_25507/tree/master/0235-lowest-common-ancestor-of-a-binary-search-tree) |
## Bucket Sort
|  |
| ------- |
| [0347-top-k-frequent-elements](https://github.com/vtu25507bhanu/APS_25507/tree/master/0347-top-k-frequent-elements) |
<!---LeetCode Topics End-->